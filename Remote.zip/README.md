I wrote this ages ago and very quickly as a proof of concept, so it's a bit horrible.

These days it lives on a Raspberry PI and does the job.

// TODO: Usage instructions. For now, as long as LIRC has an "aircon" remote, and this works from the cli using irsend it should just work.
