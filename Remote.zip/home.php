<!DOCTYPE html>
<?php
session_start();
include_once 'dbconnect.php';

if (!isset($_SESSION['userSession'])) {
	header("Location: index.php");
}

$query = $DBcon->query("SELECT * FROM tbl_users WHERE user_id=".$_SESSION['userSession']);
$userRow=$query->fetch_array();
$DBcon->close();
?>
<html>
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Welcome - <?php echo $userRow['email']; ?></title>
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen"> 
	<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen"> 
	<link rel="stylesheet" href="style.css" type="text/css" />
		
		
		<script src="http://code.jquery.com/jquery-latest.js"></script>
		
		<style>
<!--			body {
				padding-top: 60px; /* 60px to make the container go all the way to the bottom of the topbar */
			} -->

			.remote { text-align: center; }

			.remote .btn {
				height: 20%;
				width: 30%;
				
			}

			.remote .btn {
				padding: 30px;
				font-size: 30px;
			}

			#log {
				overflow: hidden;
			}

			.log {
				font-size: 20px;
				line-height: 25px;
				padding: 20px;

				border: 3px solid #BCE8F1;
				background-color: #D9EDF7;
				color: #3A87AD;

				display: none;

				margin-bottom: 5px;
			}

			.log-error {
				border: 3px solid #EED3D7;
				background-color: #F2DEDE;
				color: #BB4F4D;
			}

			.log-success {
				border: 3px solid #D6E9C6;
				background-color: #DFF0D8;
				color: #A4C6A3;
			}

			.log-unknown {
				border: 3px solid #FBEED5;
				background-color: #FCF8E3;
				color: #C09853;
			}

		</style>
		<meta name="viewport" content="user-scalable=no">
		<meta name="mobile-web-app-capable" content="yes">
		<link rel="icon" sizes="164x297" href="icon.png">
	</head>
	<body>
	<nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
       
        <div id="navbar" class="navbar-collapse collapse">

          <ul class="nav navbar-nav navbar-right">
            <li><a href="#"><span class="glyphicon glyphicon-user"></span>&nbsp; <?php echo $userRow['username']; ?></a></li>
            <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp; Keluar</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>


	
	
	
	
	
<form href ="login.html"></form>
		<div class="container">
			<div class="remote">
				<div class="row">
					<div class="span12">
						<button class="btn btn-xs btn-primary " type="button" data-action="power">Power</button>
					</div>
				</div>

				<div class="row"><div class="span12">&nbsp;</div></div>

				<div class="row">
					<div class="span6">
						<button class="btn btn-xs btn-primary" type="button" data-action="mode">Function</button>
					</div>
					<div class="span6">
						<button class="btn btn-xs btn-primary btn-danger" type="button" data-action="tempUp">Temp Up</button>
					</div>
				</div>

				<div class="row"><div class="span12">&nbsp;</div></div>

				<div class="row">
					<div class="span6">
						<button class="btn btn-primary btn-warning" type="button-" data-action="timer">Timer</button>
					</div>
					<div class="span6">
						<button class="btn btn-primary btn-success" type="button" data-action="tempDown">Temp Down</button>
					</div>
				</div>

				<div class="row"><div class="span12">&nbsp;</div></div>

				<div class="row">
					<div class="span6">
						<div id="log"></div>
					</div>
					<div class="span3">
						<button class="btn btn-primary btn-info" type="button" data-action="speed">Fan Speed</button>
					</div>
					<div class="span3">
                                                <button class="btn btn-primary btn-info" type="button" data-action="setTemp">Set Temp</button>
                                        </div>
				</div>

			</div>
		</div>

		<script>
			function fixButtons() {
				height = (window.innerHeight - 60 - 100) / 4;
				$('.btn').css('height', height + 'px');
				$('#log').css('height', height + 'px');

				/* width = (window.innerWidth - 25) / 2;
				$('.btn').css('width', width + 'px');
				$('.btn-wide').css('width', (width * 2 + 25)+ 'px'); */
			}

			$(function() {
				window.onresize = function(event) {
					fixButtons();
				}

				fixButtons();

				function addLog(text, type) {
					var thisDiv = $(document.createElement('div'));
					thisDiv.addClass('log');
					if (type != undefined) {
						thisDiv.addClass('log-' + type);
					}
					thisDiv.text(text);
					$('#log').prepend(thisDiv);
					thisDiv.fadeIn("slow");

					setTimeout(function(){
						thisDiv.fadeOut("slow", function () {
							thisDiv.remove();
						});
					}, 2000);
				}

				$('.btn').click(function() {
					var action = $(this).data('action');
					addLog('Button Clicked: ' + action);
					var value = false;
					if (action == 'setTemp') {
						var value = prompt("What temperature?", '');
					}

					$.ajax({
						type: 'GET',
						url: 'act.php',
						data: { action: action, value: value }
					}).done(function(msg) {
						var msg = $.parseJSON(msg);
						if (msg.error != undefined) {
							addLog(msg.error, 'error');
						} else if (msg.success != undefined) {
							addLog(msg.success, 'success');
						} else {
							addLog('Unknown result.', 'unknown');
						}
					});

				});
			});
		</script>

	</body>
</html>
